python aakash_driver.py $HOME/xact_files/2.txt &
python aakash_driver.py $HOME/xact_files/7.txt &
python aakash_driver.py $HOME/xact_files/12.txt &
python aakash_driver.py $HOME/xact_files/17.txt &
wait
