python aakash_driver.py $HOME/xact_files/3.txt &
python aakash_driver.py $HOME/xact_files/8.txt &
python aakash_driver.py $HOME/xact_files/13.txt &
python aakash_driver.py $HOME/xact_files/18.txt &
wait