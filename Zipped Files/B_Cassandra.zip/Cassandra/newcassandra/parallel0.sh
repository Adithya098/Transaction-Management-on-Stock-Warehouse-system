python aakash_driver.py $HOME/xact_files/0.txt &
python aakash_driver.py $HOME/xact_files/5.txt &
python aakash_driver.py $HOME/xact_files/10.txt &
python aakash_driver.py $HOME/xact_files/15.txt &
wait
