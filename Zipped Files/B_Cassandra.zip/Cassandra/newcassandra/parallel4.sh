python aakash_driver.py $HOME/xact_files/4.txt &
python aakash_driver.py $HOME/xact_files/9.txt &
python aakash_driver.py $HOME/xact_files/14.txt &
python aakash_driver.py $HOME/xact_files/19.txt &
wait
