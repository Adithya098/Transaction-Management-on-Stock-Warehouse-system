python aakash_driver.py $HOME/xact_files/1.txt &
python aakash_driver.py $HOME/xact_files/6.txt &
python aakash_driver.py $HOME/xact_files/11.txt &
python aakash_driver.py $HOME/xact_files/16.txt &
wait
