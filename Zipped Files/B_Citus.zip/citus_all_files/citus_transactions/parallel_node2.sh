python input.py ../xact_files/2.txt &
python input.py ../xact_files/7.txt &
python input.py ../xact_files/12.txt &
python input.py ../xact_files/17.txt &
wait

