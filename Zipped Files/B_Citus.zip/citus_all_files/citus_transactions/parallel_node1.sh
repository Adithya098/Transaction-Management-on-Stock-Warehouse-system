python input.py ../xact_files/1.txt &
python input.py ../xact_files/6.txt &
python input.py ../xact_files/11.txt &
python input.py ../xact_files/16.txt &
wait

