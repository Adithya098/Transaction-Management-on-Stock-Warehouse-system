python input.py ../xact_files/4.txt &
python input.py ../xact_files/9.txt &
python input.py ../xact_files/14.txt &
python input.py ../xact_files/19.txt &
wait

