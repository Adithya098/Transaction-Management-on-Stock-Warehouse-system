python input.py ../xact_files/0.txt &
python input.py ../xact_files/5.txt &
python input.py ../xact_files/10.txt &
python input.py ../xact_files/15.txt &
wait

